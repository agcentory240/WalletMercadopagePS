<?php

/**
 * Class WalletMercadopagePS_Model_Db_Table_PaymentMethodsMercadopage
 */
class WalletMercadopagePS_Model_Db_Table_PaymentMethodsMercadopage extends Core_Model_Db_Table
{
    /**
     * @var string 
     */
    protected $_name = 'wallet_payment_systems_mercadopage';

    /**
     * @var string 
     */
    protected $_primary = 'wallet_payment_systems_mercadopage_id';
    
}